<section id="multiple-column-form">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">UPLOAD DE BACKGROUNDS</h4>
					<p class="px-0"><b>Tamanho recomendado (1980px x 1080px).png ou jpg</b>
					
                </div>
                <div class="card-body">
<center><p class="px-0"><b>AQUI FAZ UPLOAD DO BACKGROUND REVENDA.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeBkrv.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
	   <p>
				</p>
    </form>
</div>
<center><p class="px-0"><b>AQUI FAZ UPLOAD  DO BACKGROUND ADMIN.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeBkad.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
	   <p>
				</p>		
    </form>
</br>	
<center><p class="px-0"><b>AQUI FAZ UPLOAD DO BACKGROUND DA LOJA.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeStore.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
    </form>	
                </div>
            </div>
        </div>
    </div>	
</section>